# Průvodce v kapse – prototyp v3.2b

Klikatelný HTML prototyp pro semestrální projekt v kurzu **AI v praxi: od nápadu k prototypu**.

## Co prototyp obsahuje

- vstup přes SMS / QR
- přehled škody v mobilu
- možnost přejmenování škody pro vlastní orientaci
- nahrání foto / video dokumentace
- nahrání dokumentů ke škodě
- ověření kontaktních údajů
- sledování stavu škody
- přehled nároků
- výpočet škody
- výběr způsobu výplaty: účet, karta, PayPal
- historii škody
- možnost požádat o pomoc

## Jak spustit lokálně

Otevřete soubor `index.html` v prohlížeči.

## Jak publikovat přes GitHub Pages

1. Vytvořte nový repozitář na GitHubu.
2. Nahrajte soubor `index.html` do hlavní složky repozitáře.
3. V repozitáři otevřete **Settings → Pages**.
4. V části **Build and deployment** nastavte:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
5. Uložte nastavení.
6. GitHub po chvíli zobrazí veřejnou URL prototypu.

## Poznámka

Prototyp je určený pro testování uživatelského flow a neobsahuje reálné napojení na pojišťovnu, platební bránu ani ověření identity.