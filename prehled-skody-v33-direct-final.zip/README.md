# Přehled škody v mobilu – prototyp v3.3

Klikatelný HTML prototyp pro semestrální projekt v kurzu **AI v praxi: od nápadu k prototypu**.

## Co prototyp ukazuje

- vstup přes SMS / QR,
- mobilní přehled škody pro poškozeného,
- možnost pojmenování škody pro vlastní orientaci,
- nahrání foto / video dokumentace,
- nahrání dokumentů ke škodě,
- ověření kontaktních údajů,
- jasný stav procesu: kdo je na tahu, co je hotové a co bude následovat,
- přehled nároků,
- výsledek škody,
- souhlas s částkou / nesouhlas,
- výběr způsobu výplaty: účet, karta, PayPal,
- historie škody,
- možnost požádat o pomoc.

## Jazyková revize v3.3

Verze v3.3 je upravená podle principů klientské komunikace Direct pojišťovny:

- jednoduchý a lidský jazyk,
- konzistentní vykání,
- bez interních pojmů,
- bez slova „brzy“,
- důraz na to, kdo je právě na tahu,
- jasné rozlišení stavu „čekáme na dokumenty“ a „máme vše potřebné“.

## Jak spustit lokálně

Otevřete soubor `index.html` v prohlížeči.

## Jak publikovat přes GitHub Pages

1. Nahrajte `index.html` do hlavní složky repozitáře.
2. V repozitáři otevřete **Settings → Pages**.
3. Nastavte:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
4. Uložte.
5. Po vygenerování GitHub zobrazí veřejnou URL prototypu.

## Poznámka

Prototyp je určený pro testování uživatelského flow. Neobsahuje reálné napojení na pojišťovnu, platební bránu ani ověření identity.
